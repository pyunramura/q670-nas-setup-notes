@for %a run (0 99 1)
@  if exist fs%a:\auto.nsh then
@    fs%a:
@echo ""
@echo "     **************************************************************************"
@echo "     ***                     CW-Q670-PLUS  White                            ***"
@echo "     ***                      Enabled ASPM                                  ***"
@echo "     ***        Modify 2024-11-21       by Yonji                            ***"
@echo "     **************************************************************************"
@echo ""
@pause
@    goto AUTO
@  endif
@endfor

@goto END

:AUTO
@\auto.nsh

@if %lasterror% == 0 then
@  goto END
@endif

:END
