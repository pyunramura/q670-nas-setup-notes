cd CW-Q670-PLUS
cd BIOS
Flash.nsh