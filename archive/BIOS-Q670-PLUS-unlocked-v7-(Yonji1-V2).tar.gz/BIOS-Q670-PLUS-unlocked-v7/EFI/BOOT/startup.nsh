@for %a run (0 99 1)
@  if exist fs%a:\auto.nsh then
@    fs%a:
@echo ""
@echo "     **************************************************************************"
@echo "     ***                     CW-Q670-PLUS  White                            ***"
@echo "     ***             Modified 2024-11-23       by Yonji                     ***"
@echo "     ***                                                                    ***"
@echo "     ***              - Unlocked all ASPM-related settings                  ***"
@echo "     ***           - Option to switch on / off audio & AMT                  ***"
@echo "     ***           - DevSlp can be configured for SATA devices              ***"
@echo "     ***                     - and many other stuff                         ***"
@echo "     **************************************************************************"
@echo ""
@pause
@    goto AUTO
@  endif
@endfor

@goto END

:AUTO
@\auto.nsh

@if %lasterror% == 0 then
@  goto END
@endif

:END
